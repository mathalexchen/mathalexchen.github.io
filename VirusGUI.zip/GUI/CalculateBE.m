function BE = CalculateBE(RelInftarget,Dvirus,DAb,origP,origu,deltat,deltax,T,kon,koff)

u = origu; P = origP; curP = P;
[flux] = EvolvePDE(3,Dvirus,DAb,P,u,deltat,deltax,T,kon,koff);
TotalFlux = sum(flux,2);
Abfreefrac = cumsum(flux(:,1))/sum(TotalFlux);
RelInf = 100*Abfreefrac(end);
RelInfupper = 100; upperP = zeros(size(P));
RelInflower = 0;

while (abs(RelInf - RelInftarget) > 1)
%    abs(RelInf - RelInftarget)
    u = origu; 
    if RelInf > RelInftarget % if infectivity is higher than target, increase Ab concentration
        RelInfupper = RelInf;
        upperP = curP;
        if RelInflower == 0
            curP = 2*curP;
        else
            curP = (lowerP + curP)/2;
        end
    else % if infectivity is lower than target, decrease Ab concentration
        RelInflower = RelInf;
        lowerP = curP;
        curP = (upperP + curP)/2;
    end
	P = curP;
    [flux] = EvolvePDE(3,Dvirus,DAb,P,u,deltat,deltax,T,kon,koff);
    TotalFlux = sum(flux,2);
    Abfreefrac = cumsum(flux(:,1))/sum(TotalFlux);
    RelInf = 100*Abfreefrac(end)
    BE = P(end)/(6.67*10^-9)
end
RelInf
RelInftarget
abs(RelInf - RelInftarget);
