function varargout = ProtectionGUI(varargin)
% PROTECTIONGUI M-file for ProtectionGUI.fig
%      PROTECTIONGUI, by itself, creates a new PROTECTIONGUI or raises the existing
%      singleton*.
%
%      H = PROTECTIONGUI returns the handle to a new PROTECTIONGUI or the handle to
%      the existing singleton*.
%
%      PROTECTIONGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROTECTIONGUI.M with the given input arguments.
%
%      PROTECTIONGUI('Property','Value',...) creates a new PROTECTIONGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SurvivalSlider_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ProtectionGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ProtectionGUI

% Last Modified by GUIDE v2.5 04-May-2014 18:35:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ProtectionGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ProtectionGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ProtectionGUI is made visible.
function ProtectionGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ProtectionGUI (see VARARGIN)

% Choose default command line output for ProtectionGUI
handles.output = hObject;

set(handles.Dvirusslider,'Value',log10(1.27));
set(handles.DAbslider,'Value',log10(40));
set(handles.konslider,'Value',log10(4.26e4));
set(handles.koffslider,'Value',log10(5.46e-5));
set(handles.konedit,'String','4.26e4');
set(handles.koffedit,'String','5.46e-5');
set(handles.Lmucusslider,'Value',log10(50));
set(handles.Lsemenslider,'Value',log10(200));
set(handles.Abconcslider,'Value',log10(1));
set(handles.working,'Visible','off');
set(handles.axes1,'Visible','off');
set(handles.presetAb,'Value',5);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ProtectionGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ProtectionGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function Dvirusslider_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slideval = get(handles.Dvirusslider,'Value');
set(handles.Dvirusedit,'String', num2str(10^slideval));
UpdatePlot_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function Dvirusslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function Dvirusedit_Callback(hObject, eventdata, handles)
% hObject    handle to Dvirusedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dvirusedit as text
%        str2double(get(hObjectu,'String')) returns contents of Dvirusedit as a double


% --- Executes during object creation, after setting all properties.
function Dvirusedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dvirusedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function DAbslider_Callback(hObject, eventdata, handles)
% hObject    handle to DAbslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slideval = get(handles.DAbslider,'Value');
set(handles.DAb,'String', num2str(10^slideval));
UpdatePlot_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function DAbslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DAbslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function beta_Callback(hObject, eventdata, handles)
% hObject    handle to beta (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of beta as text
%        str2double(get(hObject,'String')) returns contents of beta as a double


% --- Executes during object creation, after setting all properties.
function beta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to beta (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function konslider_Callback(hObject, eventdata, handles)
% hObject    handle to konslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slideval = get(handles.konslider,'Value');
s = num2str(10^slideval,'%10.2e');
s = [s(1:end-4) s(end)];
set(handles.konedit,'String', s);
UpdatePlot_Callback(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function konslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to konslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function konedit_Callback(hObject, eventdata, handles)
% hObject    handle to konedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of konedit as text
%        str2double(get(hObject,'String')) returns contents of konedit as a double


% --- Executes during object creation, after setting all properties.
function konedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to konedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function koffslider_Callback(hObject, eventdata, handles)
% hObject    handle to koffslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slideval = get(handles.koffslider,'Value');
s = num2str(10^slideval,'%10.2e');
s = [s(1:end-3) s(end)];
set(handles.koffedit,'String', s);
UpdatePlot_Callback(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function koffslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to koffslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function koffedit_Callback(hObject, eventdata, handles)
% hObject    handle to koffedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of koffedit as text
%        str2double(get(hObject,'String')) returns contents of koffedit as a double


% --- Executes during object creation, after setting all properties.
function koffedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to koffedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function Lmucusslider_Callback(hObject, eventdata, handles)
% hObject    handle to Lmucusslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slideval = get(handles.Lmucusslider,'Value');
set(handles.Lmucusedit,'String', num2str(10^slideval));
UpdatePlot_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function Lmucusslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Lmucusslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function Lmucusedit_Callback(hObject, eventdata, handles)
% hObject    handle to Lmucusedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Lmucusedit as text
%        str2double(get(hObject,'String')) returns contents of Lmucusedit as a double

% --- Executes during object creation, after setting all properties.
function Lmucusedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Lmucusedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in pushbutton1.
function UpdatePlot_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.working,'Visible','on');

Dvirus = str2double(get(handles.Dvirusedit,'String'));
DAb = str2double(get(handles.DAbedit,'String'));
kon = str2double(get(handles.konedit,'String'));
koff = str2double(get(handles.koffedit,'String'));
Lmucus = str2double(get(handles.Lmucusedit,'String'));
Lsemen = str2double(get(handles.Lsemenedit,'String'));
Abconc = str2double(get(handles.Abconcedit,'String'));
deltat = str2double(get(handles.deltatedit,'String'));
gridpoints = str2double(get(handles.gridpointsedit,'String'));
deltax = (Lmucus + Lsemen)/(gridpoints-1);
T = str2double(get(handles.Tedit,'String'));

set(handles.Dvirusslider,'Value',log10(Dvirus));
set(handles.DAbslider,'Value',log10(DAb));
set(handles.konslider,'Value',log10(kon));
set(handles.koffslider,'Value',log10(koff));
set(handles.Lmucusslider,'Value',log10(Lmucus));
set(handles.Lsemenslider,'Value',log10(Lsemen));
set(handles.Abconcslider,'Value',log10(Abconc));
drawnow;

%tic
%m = survivalratewL(D0,beta,delta,L,lambda,t);
[RelativeInfectivity RelativeFlux] = Main(Dvirus,DAb,kon,koff,Lmucus,Lsemen,Abconc,deltat,deltax,T);
%toc
axes(handles.axes1);
set(handles.axes1,'Visible','on');
[h h1 h2] = plotyy(0:deltat:T,[0 RelativeFlux'],0:deltat:T,[RelativeInfectivity(1) RelativeInfectivity']); %title('Relative Infectivity over Time','Fontsize',20); 
set(h1,'LineWidth',3);
set(h2,'LineWidth',3);
set(h(1),'ytick',[0 25 50 75 100]);
set(h(2),'ytick',[0 25 50 75 100]);
xlabel('Time (s)','Fontsize',20); ylabel(h(1),'% Viral Load','Fontsize',20); ylabel(h(2),'Relative Infectivity','Fontsize',20);
set(h,'FontSize',20);
set(h,'xlim',[0 T]);
set(h,'ylim',[0 100]);
%plot(t,m); title('Survival Rate m versus t','Fontsize',20); xlabel('t','Fontsize',20); ylabel('survival rate','Fontsize',20);
set(handles.working,'Visible','off');
set(handles.relinf,'String',['Relative Infectivity = ' num2str(RelativeInfectivity(end),'%10.2f') '%']);
set(handles.totalvirus,'String',['Total Viral Load at Epithelium = ' num2str(RelativeFlux(end),'%10.2f') '%']);

function DAbedit_Callback(hObject, eventdata, handles)
% hObject    handle to DAbedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DAbedit as text
%        str2double(get(hObject,'String')) returns contents of DAbedit as a double


% --- Executes during object creation, after setting all properties.
function DAbedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DAbedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function Lsemenslider_Callback(hObject, eventdata, handles)
% hObject    handle to Lsemenslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slideval = get(handles.Lsemenslider,'Value');
set(handles.Lsemenedit,'String', num2str(10^slideval));
UpdatePlot_Callback(hObject, eventdata, handles);

% --- Executes during object creation, after setting all properties.
function Lsemenslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Lsemenslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function Lsemenedit_Callback(hObject, eventdata, handles)
% hObject    handle to Lsemenedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Lsemenedit as text
%        str2double(get(hObject,'String')) returns contents of Lsemenedit as a double


% --- Executes during object creation, after setting all properties.
function Lsemenedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Lsemenedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider15_Callback(hObject, eventdata, handles)
% hObject    handle to slider15 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider15 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider14_Callback(hObject, eventdata, handles)
% hObject    handle to slider14 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider14 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider13_Callback(hObject, eventdata, handles)
% hObject    handle to slider13 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider13 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider12_Callback(hObject, eventdata, handles)
% hObject    handle to slider12 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider12 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider11_Callback(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider11 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function Tedit_Callback(hObject, eventdata, handles)
% hObject    handle to Tedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Tedit as text
%        str2double(get(hObject,'String')) returns contents of Tedit as a double


% --- Executes during object creation, after setting all properties.
function Tedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Tedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider10_Callback(hObject, eventdata, handles)
% hObject    handle to slider10 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider10 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function gridpointsedit_Callback(hObject, eventdata, handles)
% hObject    handle to gridpointsedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gridpointsedit as text
%        str2double(get(hObject,'String')) returns contents of gridpointsedit as a double


% --- Executes during object creation, after setting all properties.
function gridpointsedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gridpointsedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider9_Callback(hObject, eventdata, handles)
% hObject    handle to slider9 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider9 (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function deltatedit_Callback(hObject, eventdata, handles)
% hObject    handle to deltatedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of deltatedit as text
%        str2double(get(hObject,'String')) returns contents of deltatedit as a double


% --- Executes during object creation, after setting all properties.
function deltatedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deltatedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Abconcedit_Callback(hObject, eventdata, handles)
% hObject    handle to Abconcedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Abconcedit as text
%        str2double(get(hObject,'String')) returns contents of Abconcedit as a double


% --- Executes during object creation, after setting all properties.
function Abconcedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Abconcedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function Abconcslider_Callback(hObject, eventdata, handles)
% hObject    handle to Abconcslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slideval = get(handles.Abconcslider,'Value');
set(handles.Abconcedit,'String', num2str(10^slideval));
UpdatePlot_Callback(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function Abconcslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Abconcslider (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in presetAb.
function presetAb_Callback(hObject, eventdata, handles)
% hObject    handle to presetAb (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns presetAb contents as cell array
%        contents{get(hObject,'Value')} returns selected item from presetAb

Abtype = get(handles.presetAb,'Value');
switch Abtype
    case 1 % 2G12
        kon = '1.8e5'; koff = '4.66e-3';
    case 2 % b12
        kon = '7.06e4'; koff = '2.74e-3';
    case 3 % VRC01
        kon = '1.43e4'; koff = '4.62e-5';
    case 4 %VRC03
        kon = '1.33e4'; koff = '1.26e-5';
    case 5 % NIH45-46
        kon = '4.26e4'; koff = '5.46e-5';      
    case 6 % PG9
        kon = '1.9e4'; koff = '1.95e-5';
    case 7 % PG16
        kon = '2.4e4'; koff = '6.16e-6'; 
    case 8 % VRC-CH31
        kon = '8.9e3'; koff = '9.13e-6';    
    case 9 % none
        kon = get(handles.konedit,'String');
        koff = get(handles.koffedit,'String');
end
set(handles.konedit,'String',kon);
set(handles.koffedit,'String',koff);
set(handles.konslider,'Value',log10(str2num(kon)));
set(handles.koffslider,'Value',log10(str2num(koff)));

% --- Executes during object creation, after setting all properties.
function presetAb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to presetAb (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in restoredefault.
function restoredefault_Callback(hObject, eventdata, handles)
% hObject    handle to restoredefault (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.Dvirusslider,'Value',log10(1.27));
set(handles.DAbslider,'Value',log10(40));
set(handles.konslider,'Value',log10(4.26e4));
set(handles.koffslider,'Value',log10(5.46e-5));
set(handles.Lmucusslider,'Value',log10(50));
set(handles.Lsemenslider,'Value',log10(200));
set(handles.Abconcslider,'Value',log10(1));
set(handles.working,'Visible','off');
set(handles.presetAb,'Value',5);

set(handles.Dvirusedit,'String','1.27');
set(handles.DAbedit,'String','40');
set(handles.konedit,'String','4.26e4');
set(handles.koffedit,'String','5.46e-5');
set(handles.Lmucusedit,'String','50');
set(handles.Lsemenedit,'String','200');
set(handles.Abconcedit,'String','1');
UpdatePlot_Callback(hObject, eventdata, handles);

% --- Executes on button press in readme.
function readme_Callback(hObject, eventdata, handles)
% hObject    handle to readme (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Readme;


% --- Executes on button press in CalculateBE.
function CalculateBE_Callback(hObject, eventdata, handles)
% hObject    handle to CalculateBE (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.working,'Visible','on'); drawnow;
Dvirus = 10^get(handles.Dvirusslider,'Value');
DAb = 10^get(handles.DAbslider,'Value');
kon = 10^get(handles.konslider,'Value');
koff = 10^get(handles.koffslider,'Value');
Lmucus = 10^get(handles.Lmucusslider,'Value');
Lsemen = 10^get(handles.Lsemenslider,'Value');
Abconc = 10^get(handles.Abconcslider,'Value');
deltat = str2double(get(handles.deltatedit,'String'));
gridpoints = str2double(get(handles.gridpointsedit,'String'));
deltax = (Lmucus + Lsemen)/(gridpoints-1);
T = str2double(get(handles.Tedit,'String'));

origP = zeros(round((Lsemen+Lmucus)/deltax),1); 
origP(round(Lsemen/deltax)+1:round((Lsemen+Lmucus)/deltax)) = Abconc*6.67*10^-9; % 1 ug/mL = 6.67*10^-9 M
origu = zeros(round((Lsemen+Lmucus)/deltax),4); origu(1:round(Lsemen/deltax),1) = 1;
BEtarget = get(handles.BEtargetedit,'String');
BEtarget = str2num(BEtarget);
BE = CalculateBE(100 - BEtarget,Dvirus,DAb,origP,origu,deltat,deltax,T,kon,koff);
set(handles.BE,'String',['BE_' num2str(round(BEtarget)) ' = ' num2str(BE) ' ug/mL']);

set(handles.Abconcslider,'Value',log10(BE));
set(handles.Abconcedit,'String',round(BE*100)/100);
set(handles.working,'Visible','off');
UpdatePlot_Callback(hObject, eventdata, handles);

function BEtargetedit_Callback(hObject, eventdata, handles)
% hObject    handle to BEtargetedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BEtargetedit as text
%        str2double(get(hObject,'String')) returns contents of BEtargetedit as a double



% --- Executes during object creation, after setting all properties.
function BEtargetedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BEtargetedit (see GCBO)
% eventdata  reserved - to BE defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
