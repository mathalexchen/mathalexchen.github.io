function [flux] = EvolvePDE(M,D,Da,P,u,deltat,deltax,T,kon,koff)

% M = maximum number of Ab attached to a virion
% P = density of Ab

nvec = 0:M;

totalu = sum(sum(u));

utemp = u;
u(2:size(utemp,1)+1,:) = utemp;
u(1,:) = u(2,:); u(end+1,:) = u(end,:);
Ptemp = P;
P(2:length(Ptemp)+1) = Ptemp;
P(1) = P(2); P(end+1) = P(end);
flux = zeros(T/deltat,M+1);
%%

percentpenetrated = zeros(T/deltat,1);
%tic
for t=1:T/deltat    
    %% Evolution of diffusion equation by FTCS for Ab and virus
    fluxtemp = 0;
    ufac = 4;
    for j=1:ufac
        fluxtemp = fluxtemp + D*squeeze(u(end-1,:))*deltat/deltax^2/ufac; % Flux at epithelium by Fick's law
        u = u + deltat/deltax^2*D*conv2(u,[1; -2; 1],'same')/ufac; % General diffusion law away from interface
        u(1,:) = u(2,:); u(end,:) = 0;   % Neumann condition at semen-air interface, Dirichlet at epithelium
    end
    flux(t,:) = squeeze(fluxtemp);
    percentpenetrated(t) = 100*sum(flux(t,:))/totalu;

   Pfac = max(1,2*deltat/deltax^2*Da);
   for j=1:Pfac
       P = P + deltat/deltax^2*Da*conv2(P,[1; -2; 1],'same')/Pfac; 
       P(1) = P(2); P(end) = P(end-1); 
   end
    
   %% Reaction of Ab-virus given by tridiagonal matrix update
	plusoneanti = kon*deltat*repmat(reshape(nvec(end:-1:1),[1 M+1]),[size(u,1) 1]).*repmat(P,[1 M+1]); % superdiagonal
    minusoneanti = koff*deltat*repmat(reshape(nvec,[1 M+1]),[size(u,1) 1]); % subdiagonal
    stayssame = 1 - plusoneanti - minusoneanti; % diagonal
    
    addsoneu = zeros(size(u));
    addsoneu(:,2:end) = u(:,1:end-1).*plusoneanti(:,1:end-1);
    minusoneu = zeros(size(u));
    minusoneu(:,1:end-1) = u(:,2:end).*minusoneanti(:,2:end);
    Su = stayssame.*u + addsoneu + minusoneu; % matrix multiplication done as vector addition

    u = Su;
    u(1,:) = u(2,:); u(end,:) = 0; % Neumann at semen-air, Dirichlet at epithelium        
end
%toc
%flux = squeeze(sum(flux))';
u = u(2:end-1,:);
P = P(2:end-1);
