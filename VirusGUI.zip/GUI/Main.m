%% This function quantifies the protection due to Ab attachments to virions 
% according to the model of McKinley et al. ("Modeling neutralization 
% kinetics of HIV by broadly neutralizing monoclonal antibodies in genital
% secretions coating the cervicovaginal mucosa", submitted to PLoS ONE).
% Code by Alex Chen aschen@live.unc.edu 5/4/14
%
% The plots include:
% - Flux over Time" (left axis, blue), measuring the cumulative flux of
% virus at the epithelium over time.
% - "Relative Infectivity" (right axis, green), measuring the protection given the
% Ab attachment kinetic parameters kon and koff.  
% "Relative Infectivity" is the percentage of epithelium-penetrating Env 
% free of Ab at each time, relative to the total number of 
% epithelium-penetrating Env at the final time.
%
% Calculations are done with a Forward Time Central Space scheme for
% diffusion, and a matrix update for the reaction of virus and Ab.

function [RelativeInfectivity RelativeFlux] = Main(Dvirus,DAb,kon,koff,Lmucus,Lsemen,Abconc,deltat,deltax,T)

% kon = 1.8e5; koff = 4.66e-3; % 2G12
% kon = 7.06e4; koff = 2.74e-3; % b12
% kon = 1.43e4; koff = 4.62e-5; % VRC01
% kon = 1.33e4; koff = 1.26e-5; % VRC03
% kon = 4.26e4; koff = 5.46e-5; % NIH-4546
% kon = 1.9e4; koff = 1.95e-5; % PG9
% kon = 2.4e4; koff = 6.16e-6; % PG16
% kon = 8.9e3; koff = 9.13e-6; % VRC-CH31

%% Parameters
% Dvirus = 1.27; % Virus diffusion coefficient (um^2/s)
% DAb = 40; % (um^2/s)
Mbar = Lsemen + Lmucus; % total length (um) 
% CVMlen = 50; % um
% semenlen = 200; % um
% 
% %% Numerical parameters
% deltat = 100; % s
% deltax = 10; % \mu m
% T = 7200; % s 

%% Ab concentration
P = zeros(round(Mbar/deltax),1); 
P(round(Lsemen/deltax)+1:round((Lsemen+Lmucus)/deltax)) = Abconc*6.67*10^-9; % 1 ug/mL = 6.67*10^-9 M

tic
u = zeros(round(Mbar/deltax),4); u(1:round(Lsemen/deltax),1) = 1;
totalu = sum(sum(u));
[flux] = EvolvePDE(3,Dvirus,DAb,P,u,deltat,deltax,T,kon,koff);
toc
TotalFlux = sum(flux,2);
RelativeFlux = 100*cumsum(TotalFlux)/totalu;
Abfreefrac = cumsum(flux(:,1))/sum(TotalFlux);
RelativeInfectivity = 100*Abfreefrac;
